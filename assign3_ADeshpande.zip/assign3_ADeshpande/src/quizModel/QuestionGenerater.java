package quizModel;

import java.util.Random;

import quizView.QuizDemo;

public class QuestionGenerater {
	private static String topic;
	private Fruit fruit;
	private Politics politics;
	private Animal animal;
	private int x;
	
	/**
	 * 
	 */
	public QuestionGenerater()
	{
		Random ran = new Random();
		 x =ran.nextInt(2)+0;
	}
	
	/**
	 * 
	 * @param topic
	 */
	public void decideTopic(String topic)
	{
		this.topic = topic;
			
	}
	/**
	 * 
	 * @return
	 */
	public Question1 getQuestion()
	{
		
		if(this.topic == "Fruit")
		{
			
			Fruit f = fruit.Fruitlist.get(x);
			fruit.Fruitlist.remove(x);
			
			return f;
		}
		else if(this.topic == "Politics")
		{
			Politics fl = politics.Politicslist.get(x);
			politics.Politicslist.remove(x);
			return fl;
		}
		else
		{
			Animal ani = animal.Animallist.get(x);
			animal.Animallist.remove(x);
			return ani;
		}
			
		
	}
	
	
	
	
	
}
 