package quizModel;

import java.sql.*;

public class DBConnector {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/questions";
	static final String USER = "root";
	static final String PASS = "Qwer1234";
	
	/**
	 * @exception SQLException
	 */
	public DBConnector()
	{
		Connection conn = null;
		Statement stmt = null;
		try{
		      //STEP 2: Register JDBC driver
		      Class.forName("com.mysql.jdbc.Driver");
	
		      System.out.println("Connecting to database...");
		      conn = DriverManager.getConnection(DB_URL,USER,PASS);

		      //STEP 4: Execute a query
		      System.out.println("Creating statement...");
		      stmt = conn.createStatement();
		      String fruitSql;
		      String flowerSql;
		      String AnimalSql;
		      fruitSql = "Select * from fruit";
		      flowerSql = "Select * from politics";
		      AnimalSql = "Select * from Animal";
		      
		      ResultSet rs1 = stmt.executeQuery(fruitSql);
		      while (rs1.next())
		      {
		    	 Fruit fruit = new Fruit();
		    	 	fruit.setQuestionNo(rs1.getString("QuestionNo"));
		    	 	fruit.setOp1(rs1.getString("op1"));
		    	 	fruit.setOp2(rs1.getString("op2"));
		    	 	fruit.setOp3(rs1.getString("op3"));
		    	 	fruit.setOp4(rs1.getString("op4"));
		    	 	fruit.setAns(rs1.getInt("Ans"));
		    	 	fruit.setImg(rs1.getString("img"));
		    	 	fruit.setType(rs1.getInt("type"));
		    	 	fruit.setAns2(rs1.getString("Ans2"));
		    	 	
		    	 	fruit.Fruitlist.add(fruit);
		       }
		      
		      ResultSet rs2 = stmt.executeQuery(flowerSql);
		      while (rs2.next())
		      {
		    	  Politics politics = new Politics();
		    	  politics.setQuestionNo(rs2.getString("QuestionNo"));
		    	  politics.setOp1(rs2.getString("op1"));
		    	  politics.setOp2(rs2.getString("op2"));
		    	  politics.setOp3(rs2.getString("op3"));
		    	  politics.setOp4(rs2.getString("op4"));
		    	  politics.setAns(rs2.getInt("Ans"));
		    	  politics.setImg(rs2.getString("img"));
		    	  politics.setType(rs2.getInt("type"));
		    	  politics.setAns2(rs2.getString("Ans2"));
		    	  politics.Politicslist.add(politics);
		      }
		      
		      ResultSet rs3 = stmt.executeQuery(AnimalSql);
		      while (rs3.next())
		      {
		    	  Animal animal = new Animal();
		    	  animal.setQuestionNo(rs3.getString("QuestionNo"));
		    	  animal.setOp1(rs3.getString("op1"));
		    	  animal.setOp2(rs3.getString("op2"));
		    	  animal.setOp3(rs3.getString("op3"));
		    	  animal.setOp4(rs3.getString("op4"));
		    	  animal.setAns(rs3.getInt("Ans"));
		    	  animal.setImg(rs3.getString("img"));
		    	  animal.setType(rs3.getInt("type"));
		    	  animal.setAns2(rs3.getString("Ans2"));
		    	  animal.Animallist.add(animal);
		    	 
		      }
		      		      
		      	/**
		      	 * 	      
		      	 */
		}catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }
		catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		            stmt.close();
		      }catch(SQLException se2){
		      }// nothing we can do
		      try{
		         if(conn!=null)
		            conn.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }//end finally try
		   }
		 System.out.println("Goodbye!");
	
	}

}
