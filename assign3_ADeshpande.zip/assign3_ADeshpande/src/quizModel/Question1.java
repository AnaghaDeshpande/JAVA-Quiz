package quizModel;

public interface Question1 {

	/**
	 * 
	 * @return
	 */
	public String getQuestionNo();
	public void setQuestionNo(String questionNo);
	public String getOp1();
	public void setOp1(String op1);
	
	public String getOp2();
	public void setOp2(String op2);
	
	public String getOp3();
	public void setOp3(String op3);
	
	public String getOp4();
	public void setOp4(String op4);
	
	public Question1 getObj();
	
	public String getImg();
	public int getAns();
	
	public int getType();
	public String getAns2();
}
