package quizCollector;

import quizModel.DBConnector;
import quizModel.QuestionGenerater;
import quizView.QuizDemo;


public class QuizMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DBConnector dbconnector = new DBConnector();
		
		QuizDemo quizdemo = new QuizDemo();
		QuestionGenerater quesgen = new QuestionGenerater();
		
		quizdemo.setVisible(true);
		QuizController quizcontrol = new QuizController(quizdemo, quesgen);
			
		
	}

}
