package quizCollector;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale.Category;

import javax.swing.Timer;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import quizModel.Animal;
import quizModel.Politics;
import quizModel.Fruit;
import quizModel.Question1;
import quizModel.QuestionGenerater;
import quizView.QuizDemo;
/**
 * 
 * @author Anagha
 *
 */
public class QuizController {
	
	//View class
	private QuizDemo quizdemo ;
	private QuestionGenerater quesgen;
	private static String topic = "Fruit";
	private int totalQuestionAttempted=0;
	private int totalScore;
	private int totalCorrectAns;
	Question1 ques;
	
	private static int answer;
	
	//Radio button option Selected
	private static int option;
	
	private static int type;
	private static int fruitCA , animalCA , politicsCA;
	
	/**
	 * 
	 * @param quizdemo
	 * @param quesgen
	 */
	
	 QuizController(QuizDemo quizdemo ,QuestionGenerater quesgen)
	 {
		 this.quizdemo = quizdemo;
		 this.quesgen = quesgen;
		 //Combo Box Listener ActionListener
		 this.quizdemo.comboBoxListener(new ComboListener());
		 this.quizdemo.nextButtonListener(new NextButnListener());
		 this.quizdemo.radiobtn1Listener(new Radiobtn1Listener());
		 this.quizdemo.radiobtn2Listener(new Radiobtn2Listener());
		 this.quizdemo.radiobtn3Listener(new Radiobtn3Listener());
		 this.quizdemo.radiobtn4Listener(new Radiobtn4Listener());
		 this.quizdemo.startBtnListener(new StartBtnListener());
		 this.quizdemo.endBtnListener(new EndBtnListener());
		 
		 
	 } 
	 /**
	  * 
	  * @author Anagha
	  *
	  */
	 // start Button
	 class StartBtnListener implements ActionListener
	 {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			quizdemo.displayMainPanel();
		}
		 
	 }
	 
	 // End Button
	 /**
	  * 
	  * @author Anagha
	  *
	  */
	 class EndBtnListener implements ActionListener
	 {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(type == 1)
			{
			if(option == answer )
				{
				if(totalQuestionAttempted == 10)
				{
					
				}else
				{	totalCorrectAns ++;
				
				if(ques instanceof Fruit)
				{
					fruitCA ++;
				}
				if(ques instanceof Politics)
				{
					politicsCA ++;
				}
				if(ques instanceof Animal)
				{
					animalCA ++;
				}
				}
				}
			}
			else
			{
				if(ques.getAns2().equals(quizdemo.getAnswer()))
				{
					if(totalQuestionAttempted == 10)
					{
						
					}else
						{totalCorrectAns ++;
					System.out.println("in type 2 ENDBTN ans correct "+totalCorrectAns);
					
					if(ques instanceof Fruit)
					{
						fruitCA ++;
					}
					if(ques instanceof Politics)
					{
						politicsCA ++;
					}
					if(ques instanceof Animal)
					{
						animalCA ++;
					}
				}
				}
			}
			String score = Integer.toString(totalScore) +"/"+ Integer.toString(totalQuestionAttempted *10 );
			//DefaultCategoryDataset dcd = new DefaultCategoryDataset();
			totalScore = totalCorrectAns *10;
			quizdemo.setDatasetFruit(fruitCA);
			quizdemo.setDatasetPolitics( politicsCA);
			quizdemo.setDatasetAnimal( animalCA);
			
			quizdemo.displayEndPanel(totalScore);
			
		}
		 
	 }
	 
	 // Combo Box Action Performed.
	 /**
	  * 
	  * @author Anagha
	  *
	  */
	 class ComboListener implements ActionListener
	 {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.out.println("From Quiz control..");
			topic = quizdemo.getComboItem();
			
			generateQuestion();
			quizdemo.startAnimation();
		
		}
		 
	 }
	 
	 // Next Button is Clicked
	 /**
	  * 
	  * @author Anagha
	  *
	  */
	 class NextButnListener implements ActionListener
	 {
		 
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
		
			if(type == 1)
			{
				if(option == answer )
				{
					totalCorrectAns ++;
				
					if(ques instanceof Fruit)
					{
						fruitCA ++;
					}
					if(ques instanceof Politics)
					{
						politicsCA ++;
					}
					if(ques instanceof Animal)
					{
						animalCA ++;
					}
				}
			
			}
			else
			{
				if(ques.getAns2().equals(quizdemo.getAnswer()))
				{
					totalCorrectAns ++;
					System.out.println("in type 2 ans correct "+totalCorrectAns);
					
					if(ques instanceof Fruit)
					{
						fruitCA ++;
					}
					if(ques instanceof Politics)
					{
						politicsCA ++;
					}
					if(ques instanceof Animal)
					{
						animalCA ++;
					}
				}
				
			}
			System.out.println(fruitCA + " "+ politicsCA +" "+ animalCA +" ");
			quizdemo.setTotalCorrectAns(totalCorrectAns);
			totalQuestionAttempted++;
			quizdemo.setTotQuestions(totalQuestionAttempted);
			totalScore = totalCorrectAns *10;
			quizdemo.setTotalScore(totalScore);
			if(totalQuestionAttempted == 10)
			{
				quizdemo.endQuiz();
				
			}
			generateQuestion();
			quizdemo.startAnimation();
			
			}
		 	}
	 
	 // Radio button 1
	 /**
	  * 
	  * @author Anagha
	  *
	  */
	 class Radiobtn1Listener implements ActionListener
	 {
		 
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			option = 1;
			}
		 
	 }
	
		// Radio button 2
		 /**
		  * 
		  * @author Anagha
		  *
		  */
		 class Radiobtn2Listener implements ActionListener
		 {
			 
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				option = 2;
				}
			 
		 }
		// Radio button 3
		 /**
		  * 
		  * @author Anagha
		  *
		  */
		 class Radiobtn3Listener implements ActionListener
		 {
			 
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				option = 3;
				}
			 
		 }
		 
		// Radio button 4
		 /**
		  * 
		  * @author Anagha
		  *
		  */
			 class Radiobtn4Listener implements ActionListener
			 {
				 
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					option = 4;
					}
				 
			 }
	 /**
	  * 
	  */
	public void generateQuestion()
	{
		option=1;
		quesgen.decideTopic(topic);
		 ques = quesgen.getQuestion();
		 answer=ques.getAns();
		 type = ques.getType();
		 quizdemo.displayPanel(ques.getType());	
		 //Display questions and options on Screen
		 if(ques.getType()==1){
		 quizdemo.setQuestion(ques.getQuestionNo());
		 quizdemo.setOpt1(ques.getOp1());
		 quizdemo.setOpt2(ques.getOp2());
		 quizdemo.setOpt3(ques.getOp3());
		 quizdemo.setOpt4(ques.getOp4());
		 quizdemo.setimg(ques.getImg());
		 quizdemo.setRadioBtn();
		 
		 }
		 else
		 {
			 quizdemo.setQuestionType2(ques.getQuestionNo());
			 quizdemo.setimg(ques.getImg());
			 
		 }
		 
	}
	

	
	
	

	
	
	
	
	
}
