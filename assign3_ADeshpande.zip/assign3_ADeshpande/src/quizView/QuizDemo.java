package quizView;

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.BorderLayout;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.Timer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

import javax.swing.JRadioButtonMenuItem;
import javax.swing.JLabel;

import quizCollector.QuizController;
import quizModel.QuestionGenerater;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.swing.SwingConstants;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridLayout;


/**
 * @author Anagha
 *
 */

public class QuizDemo extends JFrame{

	
	private JTextPane question;
	
	private JTextField opt1;
	private JTextField opt2;
	private JTextField opt3;
	private JTextField opt4;
	
	private JComboBox comboBox = new JComboBox();
	private JPanel panel = new JPanel(); // Question panel
	private JTextField textField;
	private JTextField textField_1;
	
	private JPanel panel_1;
	private JButton nextButton;
	private JTextField totQAttempted;
	private JTextField totCorrectQ;
	private JTextField totScore;
	private ButtonGroup group;
	private JRadioButton op1,op2,op3,op4;
	
	private JPanel cardPanel;
	private JPanel panel2;
	private CardLayout card;
	private JTextPane question1;
	private JTextField answer;
	private ImageIcon image;
	private ImageIcon smile;
	private ImageIcon laugh;
	private ImageIcon cry;
	private ImageIcon confuse;
	
	private JLabel labelImage;
	Timer timer;
	ActionListener timerListener;
	public static int xVar = 0;
	QuizController quizcontroller;
	
	
	//apd
	private JPanel cardPanel1 , startPanel , endPanel , mainPanel ;
	private CardLayout cards;
	private JButton startBtn , endBtn;
	private JLabel lblTotalCorrectAnswers;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblYouCanSelect;
	private JLabel lblYouWillBe;
	private JLabel lblYouCanEnd;
	private DefaultCategoryDataset dcd;
	private JLabel label;
	private JPanel resultPanel;
	private CardLayout cards2;
	private JLabel lblNewLabel_2;
	private JLabel result;
	
	
	/**
	 * Create the application.
	 */
	public QuizDemo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		this.setBounds(100, 100, 757, 478);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(null);
		this.setResizable(false);
		
		cardPanel1 = new JPanel();
		startPanel = new JPanel();
		startPanel.setBackground(new Color(224, 255, 255));
		endPanel = new JPanel();
		endPanel.setBackground(new Color(224, 255, 255));
		mainPanel = new JPanel();
		mainPanel.setForeground(new Color(0, 0, 255));
		mainPanel.setBackground(new Color(224, 255, 255));
		cards = new CardLayout();
		cardPanel1.setLayout(cards);
		cardPanel1.setBounds(0,0,739,427);
		startPanel.setBounds(100,100,755,477);
		endPanel.setBounds(100,100,755,477);
		mainPanel.setBounds(100,100,755,477);
		
		
		
		getContentPane().add(cardPanel1);
		
		cardPanel1.add(startPanel,"start");
		startPanel.setLayout(null);
		
		startBtn = new JButton("Start the Quiz");
		startBtn.setBackground(new Color(0, 0, 139));
		startBtn.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		startBtn.setForeground(Color.MAGENTA);
		startBtn.setBounds(303, 301, 165, 44);
		startPanel.add(startBtn);
		
		lblNewLabel = new JLabel("ONLINE QUIZ");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel.setForeground(Color.MAGENTA);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(167, 23, 397, 82);
		startPanel.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("There will be 10 Questiions");
		lblNewLabel_1.setForeground(new Color(255, 200, 0));
		lblNewLabel_1.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(122, 141, 459, 30);
		startPanel.add(lblNewLabel_1);
		
		lblYouCanSelect = new JLabel("You can select topic of your choice");
		lblYouCanSelect.setForeground(new Color(255, 200, 0));
		lblYouCanSelect.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblYouCanSelect.setHorizontalAlignment(SwingConstants.CENTER);
		lblYouCanSelect.setBounds(122, 166, 459, 30);
		startPanel.add(lblYouCanSelect);
		
		lblYouWillBe = new JLabel("You will be given 30 seconds for each question");
		lblYouWillBe.setForeground(new Color(255, 200, 0));
		lblYouWillBe.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblYouWillBe.setHorizontalAlignment(SwingConstants.CENTER);
		lblYouWillBe.setBounds(122, 207, 459, 28);
		startPanel.add(lblYouWillBe);
		
		lblYouCanEnd = new JLabel("You can end the quiz anytime");
		lblYouCanEnd.setForeground(new Color(255, 200, 0));
		lblYouCanEnd.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		lblYouCanEnd.setHorizontalAlignment(SwingConstants.CENTER);
		lblYouCanEnd.setBounds(122, 246, 459, 30);
		startPanel.add(lblYouCanEnd);
		
		label = new JLabel("This is an online Quiz.");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.ORANGE);
		label.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
		label.setBounds(111, 100, 459, 30);
		startPanel.add(label);
		cardPanel1.add(mainPanel,"main");
		cardPanel1.add(endPanel,"end");
		endPanel.setLayout(new GridLayout(1, 0, 0, 0));
		

		
		dcd = new DefaultCategoryDataset();
		JFreeChart chart = ChartFactory.createBarChart3D("Topics", "topics", "Correct Answers", dcd, PlotOrientation.VERTICAL, false, false, false);
		CategoryPlot catPlot = chart.getCategoryPlot();
		catPlot.getRenderer().setSeriesPaint(0, Color.red);
		catPlot.getRenderer().setSeriesPaint(1, Color.red);
		catPlot.getRenderer().setSeriesPaint(2, Color.red);
		catPlot.setRangeGridlinePaint(Color.BLACK);
					
		ChartPanel chartPanel = new ChartPanel(chart);
		
		
		resultPanel = new JPanel();
		cards2 = new CardLayout();
		endPanel.setLayout(cards2);
	
		endPanel.add(resultPanel,"result");
		resultPanel.setBounds(100,100,755,477);
		resultPanel.setLayout(new BorderLayout(0, 0));
		endPanel.add(chartPanel,"chart");
		chartPanel.setBounds(100,100,755,477);
		
		
		JButton detailScore =  new JButton("Get detail score");
		detailScore.setForeground(new Color(0, 51, 204));
		detailScore.setFont(new Font("Comic Sans MS", Font.BOLD, 17));
		resultPanel.add(detailScore, BorderLayout.SOUTH);
		
		lblNewLabel_2 = new JLabel("Thank you for Taking the Quiz!! Well Done!!");
		lblNewLabel_2.setForeground(new Color(0, 0, 255));
		lblNewLabel_2.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 29));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		resultPanel.add(lblNewLabel_2, BorderLayout.NORTH);
		
		result = new JLabel(" s");
		result.setForeground(new Color(153, 102, 204));
		result.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
		result.setHorizontalAlignment(SwingConstants.CENTER);
		resultPanel.add(result, BorderLayout.CENTER);
		detailScore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				cards2.show(endPanel, "chart");
			}
		});
	
		cards.show(cardPanel1, "start");
		mainPanel.setLayout(null);
		comboBox.setBackground(new Color(218, 112, 214));
		comboBox.setForeground(new Color(0, 0, 255));
		comboBox.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
				
		comboBox.setBounds(0, 216, 102, 23);
		
		comboBox.addItem("Fruit");
		comboBox.addItem("Politics");
		comboBox.addItem("Animal");
		
		
		//this.getContentPane().add(comboBox);
		mainPanel.add(comboBox);
		
		cardPanel = new JPanel();
		card = new CardLayout();
		cardPanel.setBounds(192, 169, 274, 198);
		cardPanel.setLayout(card);
		//this.getContentPane().add(cardPanel);
		mainPanel.add(cardPanel);
		
		panel2 = new JPanel();
		panel2.setBackground(new Color(224, 255, 255));
		panel2.setBounds(249, 160, 257, 207);
		panel2.setLayout(null);
		
		//question1 = new JTextField();
		question1 = new JTextPane();
		question1.setBackground(new Color(221, 160, 221));
		question1.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		question1.setBounds(0, 11, 257, 47);
		question1.setEditable(false);
		panel2.add(question1);
		
		//question1.setColumns(10);
		
		
		panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBounds(249, 160, 257, 207);
		//this.getContentPane().add(panel);
		
		panel.setLayout(null);
		//panel.setVisible(false);
		
		cardPanel.add(panel,"type1");
		
		cardPanel.add(panel2,"type2");
		
		answer = new JTextField();
		answer.setBackground(new Color(255, 255, 255));
		answer.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		answer.setBounds(66, 90, 177, 40);
		panel2.add(answer);
		answer.setColumns(10);
		
		JLabel lblAnswer = new JLabel("Answer:");
		lblAnswer.setForeground(new Color(0, 0, 255));
		lblAnswer.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		lblAnswer.setBounds(10, 93, 58, 14);
		panel2.add(lblAnswer);
		
		question = new JTextPane();
		question.setBackground(new Color(221, 160, 221));
		question.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		question.setBounds(0, 11, 257, 47);
		question.setEditable(false);
		panel.add(question);
		
		
		
		opt1 = new JTextField();
		opt1.setBackground(new Color(221, 160, 221));
		opt1.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		opt1.setBounds(32, 67, 135, 23);
		opt1.setEditable(false);
		panel.add(opt1);
		opt1.setColumns(10);
		
		opt2 = new JTextField();
		opt2.setBackground(new Color(221, 160, 221));
		opt2.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		opt2.setBounds(32, 101, 135, 23);
		opt2.setEditable(false);
		panel.add(opt2);
		opt2.setColumns(10);
		
		opt3 = new JTextField();
		opt3.setBackground(new Color(221, 160, 221));
		opt3.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		opt3.setBounds(32, 135, 135, 23);
		panel.add(opt3);
		opt3.setEditable(false);
		opt3.setColumns(10);
		
		opt4 = new JTextField();
		opt4.setBackground(new Color(221, 160, 221));
		opt4.setFont(new Font("Comic Sans MS", Font.BOLD, 13));
		opt4.setBounds(32, 173, 135, 23);
		opt4.setEditable(false);
		panel.add(opt4);
		opt4.setColumns(10);
		
	
		group = new ButtonGroup();
			
		
		op1 = new JRadioButton("");
		op1.setBackground(new Color(221, 160, 221));
		op1.setBounds(0, 67, 30, 23);
		group.add(op1);
		op1.setSelected(true);
		
		op2 = new JRadioButton("");
		op2.setBackground(new Color(221, 160, 221));
		op2.setBounds(0, 101, 30, 23);
		group.add(op2);
		
		op3 = new JRadioButton("");
		op3.setBackground(new Color(221, 160, 221));
		op3.setBounds(0, 135, 30, 23);
		group.add(op3);
		
		op4 = new JRadioButton("");
		op4.setBackground(new Color(221, 160, 221));
		op4.setBounds(0, 173, 30, 23);
		group.add(op4);
		
		panel.add(op1);
		panel.add(op2);
		panel.add(op3);
		panel.add(op4);
		
		panel_1 = new JPanel(new BorderLayout());
		panel_1.setBackground(new Color(224, 255, 255));
		panel_1.setBounds(101, 169, 90, 86);
		//this.getContentPane().add(panel_1);
		mainPanel.add(panel_1);
		
		endBtn = new JButton("End Quiz");
		endBtn.setBackground(new Color(255, 0, 255));
		endBtn.setForeground(new Color(0, 0, 255));
		endBtn.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		endBtn.setBounds(192, 393, 110, 23);
		//this.getContentPane().add(btnNewButton);
		mainPanel.add(endBtn);
		
		nextButton = new JButton("Next");
		nextButton.setBackground(new Color(255, 0, 255));
		nextButton.setForeground(new Color(0, 0, 255));
		nextButton.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		nextButton.setBounds(360, 393, 110, 23);
		//this.getContentPane().add(nextButton);
		mainPanel.add(nextButton);
		
		JLabel lblTopics = new JLabel("Topics:");
		lblTopics.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		lblTopics.setHorizontalAlignment(SwingConstants.CENTER);
		lblTopics.setForeground(new Color(0, 0, 255));
		lblTopics.setBounds(0, 191, 75, 14);
		//this.getContentPane().add(lblTopics);
		mainPanel.add(lblTopics);
		
		JLabel lblStartTheQuiz = new JLabel("Start the Quiz by Selecting Topic");
		lblStartTheQuiz.setForeground(new Color(0, 0, 255));
		lblStartTheQuiz.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		lblStartTheQuiz.setBounds(25, 129, 268, 29);
		//getContentPane().add(lblStartTheQuiz);
		mainPanel.add(lblStartTheQuiz);
		
		JLabel lblTotalQuestionsAttempted = new JLabel("Total Questions Attempted:");
		lblTotalQuestionsAttempted.setForeground(new Color(0, 0, 255));
		lblTotalQuestionsAttempted.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		lblTotalQuestionsAttempted.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalQuestionsAttempted.setBounds(486, 169, 205, 14);
		//getContentPane().add(lblTotalQuestionsAttempted);
		mainPanel.add(lblTotalQuestionsAttempted);
		
		
		totQAttempted = new JTextField();
		totQAttempted.setText("0");
		totQAttempted.setBackground(new Color(221, 160, 221));
		totQAttempted.setEditable(false);
		totQAttempted.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		totQAttempted.setBounds(701, 169, 28, 20);
		//getContentPane().add(totQAttempted);
		totQAttempted.setColumns(10);
		mainPanel.add(totQAttempted);
		
		totCorrectQ = new JTextField();
		totCorrectQ.setText("0");
		totCorrectQ.setBackground(new Color(221, 160, 221));
		totCorrectQ.setEditable(false);
		totCorrectQ.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		totCorrectQ.setBounds(701, 207, 28, 20);
		//getContentPane().add(totCorrectQ);
		totCorrectQ.setColumns(10);
		mainPanel.add(totCorrectQ);
		
		JLabel lblTotalScore = new JLabel("Total Score:");
		lblTotalScore.setForeground(new Color(0, 0, 255));
		lblTotalScore.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		lblTotalScore.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalScore.setBounds(527, 241, 150, 14);
		//getContentPane().add(lblTotalScore);
		mainPanel.add(lblTotalScore);
		
		totScore = new JTextField();
		totScore.setText("0");
		totScore.setBackground(new Color(221, 160, 221));
		totScore.setEditable(false);
		totScore.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		totScore.setBounds(701, 238, 28, 20);
		//getContentPane().add(totScore);
		totScore.setColumns(10);
		mainPanel.add(totScore);
		
		/*new code*/
		JPanel animationPanel = new JPanel();
		animationPanel.setBackground(new Color(153, 50, 204));
		animationPanel.setBounds(0, 11, 739, 54);
		//getContentPane().add(animationPanel);
		animationPanel.setLayout(null);
		mainPanel.add(animationPanel);
		
		smile = new ImageIcon("smile1.jpg");
		laugh = new ImageIcon("laugh1.jpg");
		cry = new ImageIcon("cry1.jpg");
		confuse = new ImageIcon("confuse1.jpg");
		JLabel lblTime = new JLabel(laugh,JLabel.CENTER);
		lblTime.setBackground(new Color(255, 255, 0));
		lblTime.setBounds(0, 0, 67, 53);
		animationPanel.add(lblTime);
		
		lblTotalCorrectAnswers = new JLabel("Total Correct Answers:");
		lblTotalCorrectAnswers.setForeground(new Color(0, 0, 255));
		lblTotalCorrectAnswers.setFont(new Font("Comic Sans MS", Font.BOLD, 15));
		lblTotalCorrectAnswers.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalCorrectAnswers.setBounds(486, 203, 191, 14);
		mainPanel.add(lblTotalCorrectAnswers);

	
		labelImage = new JLabel(image,JLabel.CENTER);
		
		
		animationPanel.setVisible(true);
		
		timerListener = new ActionListener() {
			int x = 0 , xVel = 4;
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(x < 0 || x> 700)
				{
					xVar=0;
					startBegining();
				}
				if (xVar == 0)
				{
				x=0;
				lblTime.setBounds(x, 0, 67, 53);
				x=x+xVel;
				xVar = x;
				
				repaint();
				}
				else
				{
					if(x > 0&& x <=170)
					{
						lblTime.setIcon(laugh);
					}
					else if (x >170 && x <= 350)
					{
						lblTime.setIcon(smile);
					}
					else if(x > 350 && x <= 520)
					{
						lblTime.setIcon(confuse);
					}
					else  if(x>520&& x<=700)
					{
						lblTime.setIcon(cry);
					}
					
				}
					lblTime.setBounds(x, 0, 67, 53);
					x=x+xVel;
					xVar = x;
					repaint();
				}
			
		};
		
		
		
		}
	/**
	 * 
	 * @author Anagha
	 */
	public void startAnimation()
	{	
		cardPanel.setVisible(true);
		xVar = 0;
		if (timer == null) {
            timer = new Timer(180, timerListener);
            timer.start();  // Make the time start running.
                   
         }
	
	
	}
	/**
	 * 
	 * @param action
	 * @author Anagha
	 */
	public void startBtnListener(ActionListener action)
	{
		startBtn.addActionListener(action);
	}
	/**
	 * 
	 * @param action
	 * @author Anagha
	 */
	public void endBtnListener(ActionListener action)
	{
		endBtn.addActionListener(action);
	}
	
	/**
	 * 
	 * @param action
	 */
	public void comboBoxListener(ActionListener action)
	{
		 
		comboBox.addActionListener(action);
	}
	/**
	 * 
	 * @param action
	 */
	public void nextButtonListener(ActionListener action)
	{
		
		nextButton.addActionListener(action);
		
	}
	/**
	 * 
	 * @param action
	 */
	public void radiobtn1Listener(ActionListener action)
	{
		op1.addActionListener(action);
	}
	public void radiobtn2Listener(ActionListener action)
	{
		op2.addActionListener(action);
	}
	public void radiobtn3Listener(ActionListener action)
	{
		op3.addActionListener(action);
	}
	public void radiobtn4Listener(ActionListener action)
	{
		op4.addActionListener(action);
	}
	
	
	/**
	 * 
	 * @return
	 */
	public String getComboItem()
	{
		return((comboBox.getSelectedItem()).toString());
		
	}
	public void setQuestion(String ques)
	{
		this.question.setText(ques);
	}
	public void setOpt1(String opt1)
	{
		this.opt1.setText(opt1);
	}
	public void setOpt2(String opt2)
	{
		this.opt2.setText(opt2);
	}
	public void setOpt3(String opt3)
	{
		this.opt3.setText(opt3);
	}
	public void setOpt4(String opt4)
	{
		this.opt4.setText(opt4);
	}
	// Total Correct Answers
	/**
	 * 
	 * @param totCorrectQ
	 */
	public void setTotalCorrectAns(int totCorrectQ)
	{
		this.totCorrectQ.setText(Integer.toString(totCorrectQ));
	}
	
	// Total Number of Questions
	/**
	 * 
	 * @param totQAttempted
	 */
		public void setTotQuestions(int totQAttempted)
		{
			this.totQAttempted.setText(Integer.toString(totQAttempted));
		}
		
	// Total Score
	/**
	 * 
	 * @param totScore
	 */
		public void setTotalScore(int totScore)
		{
			this.totScore.setText(Integer.toString(totScore));
		}
		
	// Every new question Set first radio button
		/**
		 * 
		 */
		public void setRadioBtn()
		{
			op1.setSelected(true);
		}
		/**
		 * 
		 * @param type
		 */
	public void displayPanel(int type)
	{
		nextButton.setEnabled(true);
		endBtn.setEnabled(true);
		if(type == 1)
		{
			card.show(cardPanel, "type1");
			panel_1.setVisible(false);		
			
			
		}
		else
			card.show(cardPanel,"type2");
			answer.setText("");
	}
	/**
	 * 
	 * @return
	 */
	public String getAnswer()
	{
		return ((answer.getText()).toString());
	}
	/**
	 * 
	 * @param question1
	 */
	public void setQuestionType2(String question1)
	{
		this.question1.setText(question1);
	}
	/**
	 * 
	 * @param img
	 */
	public void setimg(String img)
	{
		
		image = new ImageIcon(img);
		labelImage.setIcon(image);
		panel_1.add(labelImage);
		labelImage.setBounds(149, 160, 90, 90);
		if(img != null)
		{panel_1.setVisible(true);
		labelImage.setVisible(true);}
		else
		{panel_1.setVisible(false);
		labelImage.setVisible(false);
			
		}
	
	}
	/**
	 * 
	 */
	public void startBegining()
	{
		nextButton.doClick();
	}
	/**
	 * @author Anagha
	 */
	public void displayMainPanel()
	{
		cards.show(cardPanel1, "main");
		nextButton.setEnabled(false);
		endBtn.setEnabled(false);
		cardPanel.setVisible(false);
		
	}
	/**
	 * 
	 * @param score
	 */
	public void displayEndPanel(int score)
	{
		
		cards.show(cardPanel1, "end");
		cards2.show(endPanel, "result");
		System.out.println("SCOREEEE"+score);
		
		result.setText("You Scored : "+ Integer.toString(score)+"/100");
		//Score.setText(score);
	}
	/**
	 * 
	 * @param value
	 */
	public void setDatasetFruit(int value)
	{
		dcd.setValue(value, "Fruit", "Fruit");
		
	}
	/**
	 * 
	 * @param value
	 */
	public void setDatasetPolitics(int value)
	{
		dcd.setValue(value, "", "Politics");
		
	}
	/**
	 * 
	 * @param value
	 */
	public void setDatasetAnimal(int value)
	{
		dcd.setValue(value, "", "Animal");
		
	}
	/**
	 * 
	 */
	public void endQuiz()
	{
		endBtn.doClick();
	}
}
